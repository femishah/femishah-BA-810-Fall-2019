//During the test the env variable is set to test
process.env.NODE_ENV = 'test';

//Require the dev-dependencies
let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../index.js');
let should = chai.should();
var mongoose = require("mongoose"),
    Gadget = require('../app/models/widgets');


chai.use(chaiHttp);

describe('Widget', () => {
    beforeEach((done) => {
        User.remove({}, (err) => {
            done();
        });
    });
   
    it('it should GET all the users', (done) => {
        // User.remove({}, (err) => { });
        var widget = new User({
            "Boo": "ABC",
            "Hoo": Date.now()
        });
        widget.save((err, widget) => {
            chai.request(server)
                .get('/api/widgets')
                .end((err, res) => {
                    res.should.have.status(200);
                    res.body.should.be.a('array');
                    res.body.length.should.be.eql(1);
                    done();
                });

        });
    });

    it('it should DELETE a user given the id', (done) => {
        var widget = new User({
            "Boo": "ABC",
            "Hoo": Date.now()
        });
        widget.save((err, widget) => {
            chai.request(server)
                .delete('/api/widgets/' + widget.id)
                .end((err, res) => {
                    res.should.have.status(200);
                    done();
                });
        });
    });

});





