export default {
  debug: false,
  testing: false
};
